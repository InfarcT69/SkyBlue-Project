function love.conf(t)
    t.window.title = 'Celeste Chafa'
    t.window.width = 854
    t.window.height = 480
    t.window.resizable = true
    t.window.minwidth = 854
    t.window.minheight = 480
end
